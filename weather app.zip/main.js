//variable 
const apikey='c661c7b2d65e0cca5d00986acc7841a7'

  var apiurl=`https://api.openweathermap.org/data/2.5/weather?units=metric&q=`
  
  const input=document.querySelector('.input')
  
  const searchbtn=document.querySelector('.searchbtn')
  
  const imgicon=document.querySelector('.img ')
  const weatherinfo=document.querySelector('.weatherinfo')
const humidityinfo=document.querySelector('.humidityinfo')
  const windinfo=document.querySelector('.windinfo')
  
  //async function 
  
async function weatherapi(place) {
  
  var response=await fetch(apiurl+place+`&appid=${apikey}`)
  
  var data=await response .json()
  
  console.log(data)
  if(data.cod=='404')
  {
    document.querySelector('.temp').innerHTML='city not found'
    document.querySelector('.place').innerHTML=''
    document.querySelector('.humidity').innerHTML=''
    document.querySelector('.windspeed').innerHTML=''
    weatherinfo.style.display='flex'
    humidityinfo.style.display='none'
     windinfo.style.display='none'
     imgicon.style.display='none'
  }
  else {
    document.querySelector('.temp').innerHTML=Math.round(data.main.temp)+'°c'
  
  document.querySelector('.humidity').innerHTML=data.main.humidity
  
  document.querySelector('.windspeed').innerHTML=data.wind.speed+'m/s'
  
   document.querySelector('.place').innerHTML=data.name
  
  
   
   //if statement to weather icon
   
  if (data.weather[0].main=='Rain') {
    imgicon.src='/Rainy_Weather_Icon_PNG_Clip_Art-1497.png'
     }
    else if(data.weather[0].main == 'Clouds') {
  imgicon.src = '/6316168.png'
  
}
  else if(data.weather[0].main == 'Clear') {
  imgicon.src = '/Sunny-icon.png'
   
 }
 
 weatherinfo.style.display='flex'
 humidityinfo.style.display='flex'
 windinfo.style.display='flex'
  }
 
}

//search button 

searchbtn.addEventListener('click',()=>{
  weatherapi(input.value.trim())
  
})


